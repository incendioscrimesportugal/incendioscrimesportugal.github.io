let tabela_01, seccoes_tronco, os_meus_elementos;

function preload ()
{
  tabela_01 = loadTable("tabela final - lab proj - Folha1.csv", "csv", "header");
  seccoes_tronco = [];
  seccoes_tronco[0] = loadImage ("parte 7 v2.png");
  seccoes_tronco[1] = loadImage ("parte 6 v2.png");
  seccoes_tronco[2] = loadImage ("parte 5 v2.png");
  seccoes_tronco[3] = loadImage ("parte 4 v2.png");
  seccoes_tronco[4] = loadImage ("parte 3 v2.png");
  seccoes_tronco[5] = loadImage ("parte 2 v2.png");
  seccoes_tronco[6] = loadImage ("parte 1 v2.12.png");
  seccoes_tronco[7] = loadImage ("tronco principal v3.12.png");
  //maps[6] = loadImage ("https://hello.p5js.org/assets/p5-sq-reverse.svg");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  importData();
}


function draw() 
{
  background(220);
  
  imageMode (CENTER);
  
  drawData();
}


function importData()
{
  os_meus_elementos = [];

  for (let r=0; r<tabela_01.getRowCount(); r++)
    {
      //console.log (tabela_01.getRow(r) );
      
      const year = tabela_01.getString (r,"ano" );
      const area = tabela_01.getNum (r,"area_portugal continental" );
      const crimes = tabela_01.getNum (r,"numero de crimes florestais" );
      
      //console.log(year)
      //console.log(area)
      //console.log(crimes)
      
      os_meus_elementos[r] = new DataElement (year, area, crimes);
    }
}


function drawData() 
{
  for (let i=0; i<os_meus_elementos.length; i++) 
  {
    os_meus_elementos[i].drawDataElement();
  }
}


class DataElement 
{
  constructor (anos, area_texto, crimes_texto) 
  {
    this.year = anos;
    this.area = area_texto;
    this.crimes = crimes_texto;
  }
  
  drawDataElement()
  {
    const espacamento_vertical = height/seccoes_tronco.length;
    console.log(espacamento_vertical);

    for (let i=0; i<seccoes_tronco.length; i++) 
    {
      const x = width/2;
      const y = i*espacamento_vertical + espacamento_vertical;
      image (seccoes_tronco[i], x, y, 200, 200)
     
      //legendas
      text (this.crimes, x+100, y);
      text (this.area+" ha", x-200, y);
      
      text (this.year, x, y);
      
      //Títulos
      text ("NUMERO DE CRIMES FLORESTAIS", x+90,espacamento_vertical/14);
      text ("AREA DE PORTUGAL QUEIMADA", x-260,espacamento_vertical/14);
      
      //console.log(espacamento_vertical);
      }
  }
}

function windowResized()
{
  resizeCanvas (windowWidth, windowHeight);
}